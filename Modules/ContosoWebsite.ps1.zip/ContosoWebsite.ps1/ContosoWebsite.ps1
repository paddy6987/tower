Configuration ContosoWebsite
{
 
    # Import the module that contains the resources we're using.
    Import-DscResource -ModuleName PsDesiredStateConfiguration

  param ($MachineName)

  Node $MachineName
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = �Present�
      Name = �Web-Server�
    }

    #Install ASP.NET 4.5
    WindowsFeature ASP
    {
      Ensure = �Present�
      Name = �Web-Asp-Net45�
    }

     WindowsFeature WebServerManagementConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = "Present"
    }
      # The second resource block ensures that the website content copied to the website root folder.
    File WebsiteContent
   {
            Ensure = 'Present'
            SourcePath = 'https://github.com/paddy6987/tower/blob/master/index.html'
            DestinationPath = 'c:\inetpub\wwwroot'
   }
  }
} 