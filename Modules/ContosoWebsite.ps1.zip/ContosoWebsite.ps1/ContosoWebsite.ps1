Configuration ContosoWebsite
{
 
  param ($MachineName)

  Import-DscResource -ModuleName PsDesiredStateConfiguration

  Node $MachineName
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = "Present"
      Name = "Web-Server"
    }

    #Install ASP.NET 4.5
    WindowsFeature ASP
    {
      Ensure = "Present"
      Name = "Web-Asp-Net45"
    }

     WindowsFeature WebServerManagementConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = "Present"
    }
    # The second resource block ensures that the website content copied to the website root folder.
      File index.html
    {
        DestinationPath = "C:\inetpub\wwwroot"
        SourcePath = "https://raw.githubusercontent.com/paddy6987/tower/master/index.html"
        Ensure = "Present"
        Type = "File"
        Force = $true
    }
     
  }
} 