Configuration ContosoWebsite
{
  param ($MachineName)

  Node $MachineName
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = �Present�
      Name = �Web-Server�
    }

    #Install ASP.NET 4.5
    WindowsFeature ASP
    {
      Ensure = �Present�
      Name = �Web-Asp-Net45�
    }

     WindowsFeature WebServerManagementConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = "Present"
    }
    File FileDemo 
    {
        DestinationPath = 'C:\inetpub\wwwroot\index.html'
            Ensure = "Present"
            Contents = '<html>
                      <head><title>Pradnesh.com</title>
                      </head>
		      <body>
		      <img src = "http://testear.org/wp-content/uploads/2010/09/logo-globant-home.png">
		      <h1 ><marquee bgcolor="white"><font color="green">Welcome to Globant | Openings for freshers</font></marquee></h1>
		      <center>
		      <h4> <a href="http://bit.ly/2MoHWzR" > Register here for fresher Drive  </a></var> </h4>
		      </body>
                      </html>
                      </head>
                      <body>'
    }
  }
} 

